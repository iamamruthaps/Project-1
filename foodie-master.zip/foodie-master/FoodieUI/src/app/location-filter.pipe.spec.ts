import { LocationFilterPipe } from './location-filter.pipe';

describe('LocationFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new LocationFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
