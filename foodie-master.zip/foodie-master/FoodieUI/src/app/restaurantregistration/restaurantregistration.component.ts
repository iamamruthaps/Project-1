import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantregistration',
  templateUrl: './restaurantregistration.component.html',
  styleUrls: ['./restaurantregistration.component.css']
})
export class RestaurantregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
