package com.ust.foodieApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodieAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
