package com.ust.foodie.restuarants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestuarantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
