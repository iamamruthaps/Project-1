
package com.cg.authservice.enums;

public enum OrderStatus {

  NEW, DELIVERED, CANCELLED;
}
