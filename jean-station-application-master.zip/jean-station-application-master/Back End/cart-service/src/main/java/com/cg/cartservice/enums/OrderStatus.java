package com.cg.cartservice.enums;

public enum OrderStatus {

  NEW, DELIVERED, CANCELLED, OUT_FOR_DELIVERY, DISPATCHED;
}
