package com.cg.cartservice.enums;

public enum ProductStatus {
  ENABLED, DISABLED;

}