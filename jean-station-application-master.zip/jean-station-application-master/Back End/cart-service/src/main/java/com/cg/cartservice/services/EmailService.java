package com.cg.cartservice.services;

import com.cg.cartservice.dto.NotificationEmail;

public interface EmailService {

  public void SendEmail(NotificationEmail email);

}
