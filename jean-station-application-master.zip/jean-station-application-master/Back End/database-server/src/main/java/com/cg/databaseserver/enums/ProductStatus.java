
package com.cg.databaseserver.enums;

public enum ProductStatus {
  ENABLED, DISABLED;

}