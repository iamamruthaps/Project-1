
package com.cg.gatewayserver.enums;

public enum OrderStatus {

  NEW, DELIVERED, CANCELLED;
}
