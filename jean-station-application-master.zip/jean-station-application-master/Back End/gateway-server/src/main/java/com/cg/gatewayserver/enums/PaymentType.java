
package com.cg.gatewayserver.enums;

public enum PaymentType {

  COD, ONLINE

}
