
package com.cg.orderservice.entities;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import com.cg.orderservice.enums.OrderStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeliveryHistory {

  @Id
  @SequenceGenerator(name = "delivery_id_sequence", initialValue = 100001, allocationSize = 1)
  @GeneratedValue(generator = "delivery_id_sequence", strategy = GenerationType.SEQUENCE)
  private Long deliveryId;
  private Long orderId;
  private Long updatedOn;
  @Enumerated(EnumType.STRING)
  private OrderStatus orderStatus;
}
