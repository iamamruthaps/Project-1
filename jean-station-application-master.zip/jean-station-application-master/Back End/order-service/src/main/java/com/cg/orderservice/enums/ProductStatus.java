
package com.cg.orderservice.enums;

public enum ProductStatus {
  ENABLED, DISABLED;

}