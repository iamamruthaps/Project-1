
package com.cg.orderservice.repositories;

import java.util.List;

import com.cg.orderservice.entities.DeliveryHistory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeliveryHistoryRepository extends JpaRepository<DeliveryHistory, Long> {

  List<DeliveryHistory> findByOrderId(Long orderId);

}
