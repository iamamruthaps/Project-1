
package com.cg.orderservice.schedulingtask;

import java.util.Date;
import java.util.List;

import com.cg.orderservice.entities.OrderMain;
import com.cg.orderservice.enums.OrderStatus;
import com.cg.orderservice.repositories.OrderMainRepository;
import com.cg.orderservice.services.DeliveryHistoryService;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@AllArgsConstructor
@Slf4j
public class DeliveryHistoryScheduledService {

  private final OrderMainRepository orderRepository;
  private final DeliveryHistoryService deliveryService;

  @Scheduled(cron = "5 * * * * *")
  public void autoApproveLeave() {
    log.info("Executed at " + new Date());
    List<OrderMain> orders = orderRepository.fetchOrderBasedOnStatus();
    // Update order status
    for (OrderMain orderMain : orders) {
      if (orderMain.getOrderStatus().equals(OrderStatus.NEW))
        orderMain.setOrderStatus(OrderStatus.DISPATCHED);
      else if (orderMain.getOrderStatus().equals(OrderStatus.DISPATCHED))
        orderMain.setOrderStatus(OrderStatus.OUT_FOR_DELIVERY);
      else if (orderMain.getOrderStatus().equals(OrderStatus.OUT_FOR_DELIVERY))
        orderMain.setOrderStatus(OrderStatus.DELIVERED);
      orderRepository.save(orderMain);
      // Add to delivery table
      deliveryService.createEntry(orderMain.getOrderId(), orderMain.getOrderStatus());
    }

  }
}
