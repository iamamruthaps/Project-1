
package com.cg.orderservice.services;

import java.util.List;

import com.cg.orderservice.dto.UpdateStatusDto;
import com.cg.orderservice.entities.OrderMain;

public interface OrderService {

  List<OrderMain> fetchByUserId(Long userId);

  List<OrderMain> fetchAll();

  OrderMain findByOrderId(Long orderId);

  OrderMain updateOrderStatus(UpdateStatusDto updateStatusDto);

}
