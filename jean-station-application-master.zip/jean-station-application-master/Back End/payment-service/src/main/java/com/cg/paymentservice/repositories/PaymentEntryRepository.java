
package com.cg.paymentservice.repositories;

import com.cg.paymentservice.entities.PaymentEntry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentEntryRepository extends JpaRepository<PaymentEntry, Long> {
  
}
