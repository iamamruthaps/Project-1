   
package com.cg.productservice.enums;

public enum ProductStatus {
  ENABLED, DISABLED;

}
