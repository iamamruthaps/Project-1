 
package com.cg.productservice.repositories;

import java.util.List;

import com.cg.productservice.entities.ProductInfo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductInfoRepository extends JpaRepository<ProductInfo, Long> {

	// List<ProductInfo> fetchProductByCategory(String category);

	List<ProductInfo> findByProductNameContainingIgnoreCase(String name);
}
