 
package com.cg.productservice.services;

import java.util.List;

import com.cg.productservice.entities.ProductCategory;

public interface ProductCategoryService {

  List<ProductCategory> fetchAllCategories();

  ProductCategory createCategory(ProductCategory productCategory);

  ProductCategory findById(Long id);

}
