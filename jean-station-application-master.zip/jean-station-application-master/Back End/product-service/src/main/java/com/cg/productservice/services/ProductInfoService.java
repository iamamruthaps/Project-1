
package com.cg.productservice.services;

import java.util.List;

import com.cg.productservice.dto.ProductInfoDto;
import com.cg.productservice.dto.ProductInfoRequest;
import com.cg.productservice.dto.StockDto;

import org.springframework.data.domain.Page;

public interface ProductInfoService {

  public List<ProductInfoDto> fetchAll();

  public List<ProductInfoDto> fetchByCategory(String category);

  public ProductInfoDto fetchById(Long id);

  public List<ProductInfoDto> fetchByName(String name);

  public ProductInfoDto increaseStock(StockDto stockDto);

  public ProductInfoDto reduceStock(StockDto stockDto);
  
  public ProductInfoDto updateStock(StockDto stockDto);

  public boolean removeProduct(Long productId);

  public ProductInfoDto add(ProductInfoRequest productInfoDto);

  public ProductInfoDto update(ProductInfoRequest productInfoDto);

  Page<ProductInfoDto> fetchProductPages(Integer pageNo, Integer pageSize, String sortBy, String direction);

}
