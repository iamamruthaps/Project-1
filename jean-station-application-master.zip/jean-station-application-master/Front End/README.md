# Steps to use ngBd bootstrap

1. Add te dependency using `ng add @ng-bootstrap/ng-bootstrap`
2. Copy documenttion components
3. Make ure all pipes are specified in `providers: []`
4. Make sure all directives are specified in `declarations: []`
