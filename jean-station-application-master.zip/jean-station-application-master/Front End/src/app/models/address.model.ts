export class Address {
  addressId: number;
  city: string;
  state: string;
  area: string;
  pincode: string;
}
