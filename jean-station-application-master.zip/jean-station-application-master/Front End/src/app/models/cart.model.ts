import { ProductInOrder } from './product-in-order.model';

export class Cart {
  cartId: number;
  products: ProductInOrder[];
}
