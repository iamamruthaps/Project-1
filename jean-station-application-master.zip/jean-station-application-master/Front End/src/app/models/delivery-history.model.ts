export class DeliveryHistory {
  deliveryId: number;
  orderId: number;
  updatedOn: Date;
  orderStatus: string;
}
