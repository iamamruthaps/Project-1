export class Item {
  productId: number;
  quantity: number;
}
