export enum OrderStatus {
  DISPATCHED = 'Dispatched',
  OUT_FOR_DELIVERY = 'Out for Deliver',
  DELIVERED = 'Delivered',
  NEW = 'Order Created',
  CANCELLED = 'Order Cancelled'
}
