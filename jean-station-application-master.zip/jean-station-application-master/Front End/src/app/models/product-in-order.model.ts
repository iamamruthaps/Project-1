export class ProductInOrder {
  productInOrderId: number;
  productId: number;
  productName: string;
  productDescription: string;
  productIcon: string;
  productCategory: string;
  productPrice: number;
  productStock: number;
  totalPrice: number;
  discountPercent: number;
}
