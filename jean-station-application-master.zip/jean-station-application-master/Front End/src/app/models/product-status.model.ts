export enum ProductStatus {
  ENABLED = 'Enabled',
  DISABLED = 'Disabled',
}
