export class Product {
  categoryId: number;
  categoryName: string;
  productDescription: string;
  productIcon: string;
  productId: number;
  productName: string;
  productPrice: number;
  productStatus: string;
  productStock: number;
  discountPercent: number;
}
