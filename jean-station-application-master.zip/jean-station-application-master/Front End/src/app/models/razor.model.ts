export class RazorPay {
  razorpay_payment_id;
  razorpay_order_id;
  razorpay_signature;
}
