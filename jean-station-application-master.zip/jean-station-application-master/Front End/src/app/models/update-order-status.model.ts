export class UpdateOrderStatus {
  orderId: number;
  status: string;
}