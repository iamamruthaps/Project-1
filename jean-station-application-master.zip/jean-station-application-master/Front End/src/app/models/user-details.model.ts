import { Address } from './address.model';

export class UserDetails {
  address: Address;
  emailId: string;
  firstName: string;
  lastName: string;
  phoneNo: string;
  role: string;
  userId: number;
  username: string;
}
