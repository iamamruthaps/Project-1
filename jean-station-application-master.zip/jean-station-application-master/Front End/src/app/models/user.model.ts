export class User {
  userId: string;
  username: string;
  token: string;
  role: string;
}
