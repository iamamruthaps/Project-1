
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DeliveryHistoryService {
  orderServiceUrl = `${environment.protocol}${environment.applicationUrl}/${environment.orderService}/delivery`;

  constructor(private http: HttpClient) {}

  fetchDeliveryByOrderId(orderId) {
    return this.http.get(`${this.orderServiceUrl}/${orderId}`);
  }
}
